let PrimeiroNumero = document.querySelector ("#PrimeiroNumero")
let SegundoNumero = document.querySelector ("#SegundoNumero")
let resultado = document.querySelector ("#resultado")

function Somas (){
let var1 = Number (PrimeiroNumero.value)
let var2 = Number (SegundoNumero.value)

let Somas = var1 > var2 ? var1: var2
resultado.textContent=Somas
}


