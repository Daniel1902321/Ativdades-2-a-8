function verificarImpar() {

    var numero = document.querySelector("#numero").value;

   
    if (numero % 2 !== 0) {
        document.getElementById("resultado").innerText = numero + "número ímpar.";
    } else {
        document.getElementById("resultado").innerText = numero + " número par.";
    }
}