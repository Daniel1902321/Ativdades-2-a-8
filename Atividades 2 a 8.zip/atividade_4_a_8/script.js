let Calculo1 = document.querySelector ("#Calculo1")
let Calculo2 = document.querySelector ("#Calculo2")
let Calculo3 = document.querySelector ("#Calculo3")
let Resultado1 = document.querySelector("#Resultado1")
let Resultado2 = document.querySelector("#Resultado2")
let Resultado3 = document.querySelector("#Resultado3")
let Resultado4 = document.querySelector("#Resultado4")

function calcularValorFinal () {

let var1 =Number(Calculo1.value); 
let var2 =Number(Calculo2.value);
let var3 =Number(Calculo3.value);

let Media1 =(var1+var2+var3) / 3;
Resultado1.textContent= Media1;

let Media2 =(var1 * 3 + var2 * 2 + var3 * 5) / (3 + 2 + 5);
Resultado2.textContent=Media2;

let medias1 = Media1 + Media2;
Resultado3.textContent=medias1

let medias2 = (Media1 + Media2) / 2;
Resultado4.textContent=medias2

}