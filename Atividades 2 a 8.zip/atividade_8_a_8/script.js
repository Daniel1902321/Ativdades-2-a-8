function verificarCodigo() {

    var codigo = document.querySelector("#codigo").value;


    if (codigo === "001") {
        document.querySelector("#resultado").innerText = "Parafuso";
    } else if (codigo === "002") {
        document.querySelector("#resultado").innerText = "Porca";
    } else if (codigo === "003") {
        document.querySelector("#resultado").innerText = "Prego";
    } else {
        document.querySelector("#resultado").innerText = "Diversos";
    }
}