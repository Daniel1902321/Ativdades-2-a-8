    var precoPorQuilo = document.querySelector ("#preco_quilo")
    var quantidadeQuilos = document.querySelector ("#quantidade_quilos")
    var resultado = document.querySelector ("#resultado")

    function calcularValorFinal() {
        let var1;
        let var2;
        var1=Number(preco_quilo.value);
        var2=Number(quantidade_quilos.value)
    
        resultado.textContent=var1*var2;
    }